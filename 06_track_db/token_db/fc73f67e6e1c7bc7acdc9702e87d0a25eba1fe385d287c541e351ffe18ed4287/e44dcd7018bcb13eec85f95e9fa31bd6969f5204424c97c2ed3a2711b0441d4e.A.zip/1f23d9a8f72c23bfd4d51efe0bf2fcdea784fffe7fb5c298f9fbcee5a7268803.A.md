# gpt.work HRTDB C03 Cycle 2 정식 작업지시

## 0. gpt.logi 검수판정

`RESULT-001` `gpt.work`의 Cycle 2 견해 Package는 Exact SHA-256·Bytes·ZIP CRC·Member Filename–SHA-256·MD–JSON 결속·Python Syntax를 통과했다.

`RESULT-002` 견해의 완료상태 `PARTIAL_ADVISORY_TO_GPT_LOGI_WITH_EXPLICIT_UNCERTAINTY`는 적절하다. 불확실성은 실행을 차단하는 실패가 아니라 Cycle 2에서 검산할 경계다.

`RESULT-003` 우선힌트 `Route C — Limited Hybrid`를 Cycle 2 시작 Scope로 채택한다.

`RULE-001` 관계는 선정조건이 아니다. 선택된 Ticker가 서로 관련된다는 결론을 사전에 두지 않는다.

`RULE-002` `NO_RELATION_OBSERVED`, `NOT_COMPARABLE`, `SOURCE_GAP`, `CONTROL_FAILURE`는 모두 유효한 Cycle 2 Result다.

`RULE-003` 이번 지시는 `gpt.work@0d(t)`의 외부 Data 취득과 `Ready.Data` 형성 Assignment다. 1d·2d·3d 분석은 시작하지 않는다.

```python
BLOCK_ID = "PY-C2-000"
BLOCK_ROLE = "AUTHORITY_MODEL"
EXECUTION_POLICY = "APPROVED_EXTERNAL_DATA_ACQUISITION"

assignment = {
    "instance": "gpt.work",
    "position": "HRTDB_A::0d(t)",
    "occupation": "EXTERNAL_OBSERVATION_AND_DATA_INTAKE_TRANSFER",
    "cycle": 2,
    "cycle_id": "HRTDB_C03_CYCLE_2",
    "route": "LIMITED_HYBRID",
    "ready_data_assignment": True,
    "one_d_route_open": False,
    "relationship_is_selection_condition": False,
}
```

## 1. Exact Input Binding

### Cycle 1 Reference Axis 권위입력

- Package: `f4c1003a4cef96c3387355943b2cb5787988045a3476cd231843a5439664f00d.A.zip`
- SHA-256: `f4c1003a4cef96c3387355943b2cb5787988045a3476cd231843a5439664f00d`
- Bytes: `10884`
- Axis: `C03_REFERENCE_AXIS_1`
- State: `ACTIVE_WITH_EXPLICIT_GAPS`

### gpt.work Cycle 2 견해입력

- Canonical Alias: `78f08a4a36529e5b6b65271b6f56bbbbebdfa44f3cf64dce01a96ece1b56dfbe.A.zip`
- Transport Filename: `78f08a4a36529e5b6b65271b6f56bbbbebdfa44f3cf64dce01a96ece1b56dfbe(1).zip`
- Package SHA-256: `78f08a4a36529e5b6b65271b6f56bbbbebdfa44f3cf64dce01a96ece1b56dfbe`
- Package Bytes: `15491`
- Markdown: `3fb706453f2c7d4a2e3c5d7940f2cff65f45015f64b36b315962d8a580809a49.A.md`
- Markdown Bytes: `12550`
- JSON: `0c8deec9495341ef04f868dab0468ccc6014df148b95751bb648cf0e5fb3d1b8.A.json`
- JSON Bytes: `26231`

`RULE-010` 원 업로드 파일명의 `(1)`과 Outer `.A` 표기 차이는 Transport Alias다. 실제 SHA-256·Bytes가 Identity 권위다.

`RULE-011` 견해 Package의 원 Bytes는 수정하지 않는다. Canonical Alias는 동일 Bytes의 전달명이다.

`RULE-012` 권위입력 또는 견해입력의 Exact Binding이 실패하면 Data 취득을 시작하지 않고 `HOLD_INPUT_BINDING_FAILURE`로 반환한다.

```python
BLOCK_ID = "PY-C2-010"
BLOCK_ROLE = "ARTIFACT_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

exact_inputs = {
    "reference_axis_1": {
        "package_sha256": "f4c1003a4cef96c3387355943b2cb5787988045a3476cd231843a5439664f00d",
        "package_bytes": 10884,
    },
    "gpt_work_advisory": {
        "package_sha256": "78f08a4a36529e5b6b65271b6f56bbbbebdfa44f3cf64dce01a96ece1b56dfbe",
        "package_bytes": 15491,
        "markdown_sha256": "3fb706453f2c7d4a2e3c5d7940f2cff65f45015f64b36b315962d8a580809a49",
        "json_sha256": "0c8deec9495341ef04f868dab0468ccc6014df148b95751bb648cf0e5fb3d1b8",
    },
}
```

## 2. 승이·gpt.logi의 Scope 결정

열린 질문은 다음과 같이 판정한다.

1. **42 Cell Limited Hybrid를 승인한다.** Cycle 1의 36 Cell보다 6 Cell만 증가하며, 새 영역과 최소 Counter를 함께 연다.
2. **`AMS.SW`를 Boundary-stress Primary로 유지한다.** 복잡성 자체를 삭제하지 않고 비교불가·Gap을 Result로 보존한다.
3. **`2026-06_COUNTER`는 여섯 Instrument 전체에 적용한다.** Primary와 Control의 Counter 범위를 비대칭으로 만들지 않는다.
4. **기존 Controls를 재사용한다.** 다만 적합성이 검증되었다고 가정하지 않고 `CONTROL_CONTEXT_CANDIDATE`로 취급한다.
5. **10년 Coverage 불완전은 Cell·Pair 단위 Partial/HOLD로 처리한다.** 다른 Pair를 자동중지하지 않으며 유사 Ticker로 자동교체하지 않는다.

`RULE-020` 전체 Cycle HOLD는 Input Binding Failure, Credential/Security Failure, EODHD 전체 접근실패 또는 모든 Primary의 Source Identity를 판정할 수 없는 Systemic Failure에만 사용한다.

```python
BLOCK_ID = "PY-C2-020"
BLOCK_ROLE = "DECISION_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

scope_decision = {
    "observation_cells": 42,
    "keep_ams_sw_boundary_stress": True,
    "june_counter_all_six_instruments": True,
    "reuse_controls_as_candidates": True,
    "control_validity_preapproved": False,
    "incomplete_coverage_policy": "CELL_OR_PAIR_PARTIAL_NOT_GLOBAL_HOLD",
    "automatic_symbol_substitution": False,
}
```

## 3. Cycle 2 Instrument Scope

```python
BLOCK_ID = "PY-C2-030"
BLOCK_ROLE = "SCOPE_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

pairs = [
    {
        "pair_id": "C2-PAIR-AU",
        "primary": "COH.AU",
        "control": "STW.AU",
        "field": "AU",
        "selection_role": "INDEPENDENT_PRIMARY_PLUS_REUSED_CONTROL_CANDIDATE"
    },
    {
        "pair_id": "C2-PAIR-US",
        "primary": "ROK.US",
        "control": "SPY.US",
        "field": "US",
        "selection_role": "INDEPENDENT_PRIMARY_PLUS_REUSED_CONTROL_CANDIDATE"
    },
    {
        "pair_id": "C2-PAIR-SW",
        "primary": "AMS.SW",
        "control": "CSSMI.SW",
        "field": "SW",
        "selection_role": "BOUNDARY_STRESS_PRIMARY_PLUS_REUSED_CONTROL_CANDIDATE"
    }
]

instruments = (
    "COH.AU",
    "STW.AU",
    "ROK.US",
    "SPY.US",
    "AMS.SW",
    "CSSMI.SW",
)
```

### Pair 의미

- `COH.AU ↔ STW.AU`
- `ROK.US ↔ SPY.US`
- `AMS.SW ↔ CSSMI.SW`

`RULE-030` Pair는 관계사실이 아니라 관측단위다.

`RULE-031` `STW.AU`, `SPY.US`, `CSSMI.SW`를 중립원인·완전시장대표·적합한 Control로 사전확정하지 않는다.

`RULE-032` `AMS.SW`에서 명칭변경·Country–Venue·Corporate Action·Adjusted Basis 문제가 나타나면 해결된 것으로 추정하지 않고 독립 Gap으로 기록한다.

## 4. Cycle 2 Time Scope

```python
BLOCK_ID = "PY-C2-040"
BLOCK_ROLE = "TIME_SCOPE_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

tracks = [
    {
        "track_id": "C2-T00",
        "label": "CURRENT_2026_07",
        "from": "2026-07-01",
        "to": "2026-07-31",
        "kind": "REFERENCE_MONTH"
    },
    {
        "track_id": "C2-T01",
        "label": "MINUS_1Y_2025_07",
        "from": "2025-07-01",
        "to": "2025-07-31",
        "kind": "REFERENCE_MONTH"
    },
    {
        "track_id": "C2-T02",
        "label": "MINUS_2Y_2024_07",
        "from": "2024-07-01",
        "to": "2024-07-31",
        "kind": "REFERENCE_MONTH"
    },
    {
        "track_id": "C2-T03",
        "label": "MINUS_3Y_2023_07",
        "from": "2023-07-01",
        "to": "2023-07-31",
        "kind": "REFERENCE_MONTH"
    },
    {
        "track_id": "C2-T04",
        "label": "MINUS_5Y_2021_07",
        "from": "2021-07-01",
        "to": "2021-07-31",
        "kind": "REFERENCE_MONTH"
    },
    {
        "track_id": "C2-T05",
        "label": "MINUS_10Y_2016_07",
        "from": "2016-07-01",
        "to": "2016-07-31",
        "kind": "REFERENCE_MONTH"
    },
    {
        "track_id": "C2-TC0",
        "label": "COUNTER_2026_06",
        "from": "2026-06-01",
        "to": "2026-06-30",
        "kind": "MINIMUM_NON_JULY_COUNTER"
    }
]

assert len(pairs) * 2 * len(tracks) == 42
```

`RULE-040` 최소 State Unit은 Daily EOD Bar다.

`RULE-041` 각 기간은 Calendar Window이며 실제 반환 Row는 해당 Venue의 거래일에 따라 달라질 수 있다.

`RULE-042` `2026-06`은 최소 Counter일 뿐 계절성 분리를 완료하는 독립증거가 아니다.

`RULE-043` July 여섯 Track과 June Counter의 비대칭을 숨기지 않는다.

## 5. 외부 Data 취득 Gate

### PASS 00 — Exact Input Gate

Reference Axis와 Advisory Package를 검산한다.

### PASS 01 — Symbol·Identity Metadata Gate

각 6개 Symbol에 대해 다음을 확인한다.

- EODHD Symbol 존재 여부
- Exchange·Country·Instrument Type
- 현재 이름과 식별가능한 이전 이름
- Active/Delisted/Unknown 상태
- 2016·2026 요청 가능성
- 명백한 Listing·Ticker·Venue 변경
- Primary와 Control의 현재 역할설명 Source Pointer

### PASS 02 — Endpoint Sample Gate

각 Symbol에서 최소한 다음 Sample을 먼저 확인한다.

- 2016-07 구간
- 2026-07 구간
- 2026-06 Counter 구간

`NOT_RETURNED`는 Provider Failure로 단정하지 않는다. Symbol 상태·Coverage·Calendar·Request Parameter·Provider Date Boundary를 분리한다.

### PASS 03 — Full 42-Cell Acquisition

Sample Gate 뒤 7개 Track 전체의 Daily EOD Bar를 취득한다.

### PASS 04 — Auxiliary Source Intake

가능한 범위에서 다음을 독립적으로 취득·색인한다.

- EODHD Symbol/Exchange Metadata
- EODHD Dividends·Splits 또는 이에 대응하는 Corporate Action Source
- 공식 Issuer·Exchange·Index/ETF Source Pointer
- Calendar·Timezone·Session 판독에 필요한 공식 Source Pointer

`RULE-050` Credential·API Token·Secret은 문서·URL·로그·JSON에 저장하지 않는다.

```python
BLOCK_ID = "PY-C2-050"
BLOCK_ROLE = "ACQUISITION_MODEL"
EXECUTION_POLICY = "APPROVED_EXTERNAL_DATA_ACQUISITION"

acquisition = {
    "provider": "EODHD",
    "interval": "d",
    "requested_fields": (
        "date",
        "open",
        "high",
        "low",
        "close",
        "adjusted_close",
        "volume",
    ),
    "sample_gate": ("2016-07", "2026-07", "2026-06"),
    "full_cell_count": 42,
    "store_credentials": False,
    "official_source_pointer_intake": True,
}
```

## 6. Ready.Data Normalization

각 EOD Row는 최소한 다음을 가진다.

```python
BLOCK_ID = "PY-C2-060"
BLOCK_ROLE = "READY_DATA_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

bar_record = {
    "pair_id": None,
    "symbol": None,
    "instrument_role": "PRIMARY_OR_CONTROL_CANDIDATE",
    "track_id": None,
    "requested_from": None,
    "requested_to": None,
    "provider_date": None,
    "venue_calendar_date": None,
    "open": None,
    "high": None,
    "low": None,
    "close": None,
    "adjusted_close": None,
    "volume": None,
    "request_state": None,
    "actual_return_state": None,
    "source_pointer": None,
    "gap_ids": [],
}
```

필수 분리:

```text
Requested State ≠ Actual Returned State
Raw Close ≠ Adjusted Close
Provider Adjustment Boundary ≠ Official Corporate Action
Calendar Absence ≠ Missing Data ≠ Provider Failure
Control Candidate ≠ Validated Control
Structural Adjacency Hypothesis ≠ Observed Relation
```

`RULE-060` 원 Data Row를 평균·상관·Rank·Lag·Analogue로 변환하지 않는다.

`RULE-061` Union Calendar와 Common Calendar용 날짜색인을 모두 형성하되 실제 관계계산은 하지 않는다.

`RULE-062` 날짜부재 원인을 임의로 병합하지 않는다.

## 7. Cell·Pair 상태어

Cell 상태:

- `RETURNED_WITH_RAW_AND_ADJUSTED`
- `RETURNED_RAW_ONLY`
- `RETURNED_WITH_NULL_FIELD`
- `NO_TRADING_DAY_IN_WINDOW`
- `NOT_RETURNED`
- `SYMBOL_IDENTITY_UNRESOLVED`
- `COVERAGE_UNAVAILABLE_OR_UNPROVEN`
- `REQUEST_OR_PROVIDER_ERROR`
- `SOURCE_GAP`

Pair 상태:

- `READY_FOR_1D_WITH_EXPLICIT_GAPS`
- `PARTIAL_READY_FOR_1D`
- `PAIR_HOLD_IDENTITY_CONFLICT`
- `PAIR_HOLD_SYSTEMIC_SOURCE_FAILURE`
- `CONTROL_CONTEXT_UNVALIDATED`

`RULE-070` 하나의 Cell 또는 Pair HOLD를 다른 Pair에 전파하지 않는다.

`RULE-071` 반환되지 않은 Symbol을 유사 Symbol로 자동교체하지 않는다.

```python
BLOCK_ID = "PY-C2-070"
BLOCK_ROLE = "TERMINOLOGY_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

valid_observation_outcomes = (
    "CORRESPONDENCE_NOT_YET_TESTED",
    "DIFFERENCE_NOT_YET_TESTED",
    "CONTRADICTION_NOT_YET_TESTED",
    "NOT_COMPARABLE_POSSIBLE",
    "NO_RELATION_OBSERVED_POSSIBLE",
    "CONTROL_FAILURE_POSSIBLE",
)
```

## 8. Reference Axis 1 결속

Ready.Data는 다음 Key를 보존한다.

```text
Instrument Identity
Price Basis
Calendar / Venue Boundary
Role / Control Context
Gap State
```

`RULE-080` Reference Axis 1은 데이터 선택과 기록경계를 제공하지만 관계결론을 강제하지 않는다.

`RULE-081` Cycle 1 Ticker와 Cycle 2 Ticker의 구조적 인접성은 다음 Stage에서 검산할 질문일 뿐 Ready.Data의 사실이 아니다.

`RULE-082` Cycle 1 Result를 같은 Cycle 2 Data Row에 복제하지 않고 Exact Source Pointer로 연결한다.

## 9. 금지경계

- Cycle 2의 관계·유사성·비유사성 사전결론
- Correlation·Lag·Rank·Analogue 계산
- Method 001 또는 Method 003 실행
- Forced-nearest Historical Winner
- Price Shape 분석
- Causal·Predictive·Trading Conclusion
- Control 적합성 사전승인
- Missing Symbol 자동대체
- 날짜부재 추정병합
- Credential 저장
- 1d·2d·3d Route 자기개방
- Track DB 선언
- GitHub Mutation

```python
BLOCK_ID = "PY-C2-090"
BLOCK_ROLE = "VALIDATION_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

prohibitions = (
    "PREDECLARE_RELATION",
    "CORRELATION_LAG_RANK_ANALOGUE_COMPUTATION",
    "EXECUTE_METHOD_001_OR_003",
    "FORCED_NEAREST_WINNER",
    "PRICE_SHAPE_ANALYSIS",
    "CAUSAL_PREDICTIVE_TRADING_CONCLUSION",
    "PREAPPROVE_CONTROL_VALIDITY",
    "AUTOMATIC_SYMBOL_SUBSTITUTION",
    "INFER_MISSING_DATE_CAUSE",
    "STORE_CREDENTIAL",
    "SELF_OPEN_1D_2D_3D_ROUTE",
    "DECLARE_TRACK_DB",
    "GITHUB_MUTATION",
)
```

## 10. 필수 Ready.Data Objects

- `CYCLE2_SCOPE_IDENTITY`
- `SYMBOL_AND_INSTRUMENT_METADATA_LEDGER`
- `REQUEST_EXECUTION_LEDGER`
- `CYCLE2_EOD_BAR_DATASET`
- `RAW_ADJUSTED_PRICE_BASIS_LEDGER`
- `CORPORATE_ACTION_SOURCE_LEDGER`
- `CALENDAR_AND_DATE_PRESENCE_LEDGER`
- `PAIR_AND_CONTROL_CONTEXT_LEDGER`
- `SOURCE_AND_AVAILABILITY_GAP_LEDGER`
- `REFERENCE_AXIS_1_BINDING`
- `NEXT_1D_INPUT_INDEX`
- `ACQUISITION_VALIDATION_REPORT`

```python
BLOCK_ID = "PY-C2-100"
BLOCK_ROLE = "RESULT_OBJECT_MODEL"
EXECUTION_POLICY = "NOT_AUTOMATIC"

required_objects = (
    "CYCLE2_SCOPE_IDENTITY",
    "SYMBOL_AND_INSTRUMENT_METADATA_LEDGER",
    "REQUEST_EXECUTION_LEDGER",
    "CYCLE2_EOD_BAR_DATASET",
    "RAW_ADJUSTED_PRICE_BASIS_LEDGER",
    "CORPORATE_ACTION_SOURCE_LEDGER",
    "CALENDAR_AND_DATE_PRESENCE_LEDGER",
    "PAIR_AND_CONTROL_CONTEXT_LEDGER",
    "SOURCE_AND_AVAILABILITY_GAP_LEDGER",
    "REFERENCE_AXIS_1_BINDING",
    "NEXT_1D_INPUT_INDEX",
    "ACQUISITION_VALIDATION_REPORT",
)
```

## 11. 출력계약

출력은 하나의 Token.Data ZIP이다.

```text
<Outer ZIP 실제 SHA-256>.A.zip
├─ <Markdown 실제 SHA-256>.A.md
└─ <JSON 실제 SHA-256>.A.json
```

Markdown은 자연어와 Python 구조표현으로 Scope·Source·실행상태·Gap·검산결과를 설명한다.

JSON은 전체 Ready.Data Row와 Metadata·Source Pointer·Request State·Gap·Lineage를 구조화한다. Markdown 본문을 복제하지 않는다.

- UTF-8
- NFC
- LF
- 결정적 ZIP
- Member 2개
- Base64 본문 없음
- `.sha256.txt` 없음
- Credential 없음

```python
BLOCK_ID = "PY-C2-110"
BLOCK_ROLE = "PACKAGE_CONTRACT"
EXECUTION_POLICY = "NOT_AUTOMATIC"

output_contract = {
    "object_role": "HRTDB_C03_CYCLE2_READY_DATA_TOKEN",
    "outer": "<outer_zip_sha256>.A.zip",
    "members": 2,
    "markdown": "AI_READABLE_NATURAL_LANGUAGE_PLUS_PYTHON",
    "json": "FULL_READY_DATA_AND_MACHINE_INDEX",
    "body_base64": False,
    "sha256_sidecar": False,
    "credential_storage": False,
    "return_route": "gpt.logi@4d(xyzt)",
}
```

## 12. 완료상태와 다음 Route

허용상태:

- `PASS_CYCLE2_READY_DATA_TO_GPT_LOGI`
- `PARTIAL_PASS_CYCLE2_READY_DATA_WITH_EXPLICIT_GAPS`
- `HOLD_INPUT_BINDING_FAILURE`
- `HOLD_SYSTEMIC_SOURCE_ACCESS_FAILURE`
- `HOLD_CREDENTIAL_OR_SECURITY_FAILURE`

`RULE-120` 일부 Cell·Pair가 불완전해도 나머지 Scope가 검산 가능하면 `PARTIAL_PASS`로 반환한다.

`RULE-121` `gpt.work`는 1d Assignment를 만들거나 Cycle 2 분석완료를 선언하지 않는다.

`RESULT-010` Ready.Data가 돌아오면 `gpt.logi`가 Scope·Source·Gap을 검수하고 `gpt.x·gpt.y·gpt.z`의 Cycle 2 1d 지시를 생성한다.

```python
BLOCK_ID = "PY-C2-120"
BLOCK_ROLE = "CROSS_REPRESENTATION"
EXECUTION_POLICY = "NOT_AUTOMATIC"

next_state = {
    "current": "CYCLE2_EXTERNAL_DATA_ACQUISITION_OPEN",
    "after_result": "GPT_LOGI_READY_DATA_REVIEW",
    "after_review": "CYCLE2_1D_DIRECTIVES",
    "automatic_transition": False,
}
```
